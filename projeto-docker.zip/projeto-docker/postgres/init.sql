-- Criar a tabela alunos
CREATE TABLE alunos (
    aluno_id CHARACTER VARYING(5) NOT NULL,
    nome CHARACTER VARYING(40) NOT NULL,
    endereco CHARACTER VARYING(60),
    cidade CHARACTER VARYING(15),
    estado CHARACTER VARYING(15),
    cep CHARACTER VARYING(10),
    pais CHARACTER VARYING(15),
    telefone CHARACTER VARYING(24),
    PRIMARY KEY (aluno_id)
);

-- Inserir pelo menos 10 alunos
INSERT INTO alunos (aluno_id, nome, endereco, cidade, estado, cep, pais, telefone) VALUES
('A001', 'João Silva', 'Rua das Flores, 123', 'São Paulo', 'SP', '12345-678', 'Brasil', '1111-1111'),
('A002', 'Maria Oliveira', 'Avenida Brasil, 456', 'Rio de Janeiro', 'RJ', '22345-678', 'Brasil', '2222-2222'),
('A003', 'Carlos Santos', 'Rua das Palmeiras, 789', 'Belo Horizonte', 'MG', '32345-678', 'Brasil', '3333-3333'),
('A004', 'Ana Souza', 'Rua do Lago, 101', 'Porto Alegre', 'RS', '42345-678', 'Brasil', '4444-4444'),
('A005', 'Pedro Lima', 'Avenida Central, 202', 'Curitiba', 'PR', '52345-678', 'Brasil', '5555-5555'),
('A006', 'Juliana Alves', 'Rua da Praia, 303', 'Salvador', 'BA', '62345-678', 'Brasil', '6666-6666'),
('A007', 'Lucas Pereira', 'Rua do Sol, 404', 'Recife', 'PE', '72345-678', 'Brasil', '7777-7777'),
('A008', 'Fernanda Costa', 'Rua das Oliveiras, 505', 'Florianópolis', 'SC', '82345-678', 'Brasil', '8888-8888'),
('A009', 'Rafael Almeida', 'Avenida Atlântica, 606', 'Fortaleza', 'CE', '92345-678', 'Brasil', '9999-9999'),
('A010', 'Isabela Ramos', 'Rua das Pedras, 707', 'Manaus', 'AM', '10345-678', 'Brasil', '1010-1010');
